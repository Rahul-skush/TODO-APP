import React, { Component } from 'react'
import axios from './axios';
import Todo from './Todo'
import Spinner from './components/UI/Spinner/Spinner'
import withErrorHand from './hoc/withErrorHand';
class componentName extends Component {
    state = {
        todos: null
    }
    componentDidMount(){
        // throw "hummmmmm"
        let url = 'todos.json?orderBy="status"&status&equalTo="new"';
        axios.get(url)
        .then(resp => {
            let mytodos = []
            Object.keys(resp.data).forEach(e => {
                mytodos.push({
                    id: e,
                    ...resp.data[e]
                })
            })
            this.setState({
                todos: mytodos
            })
        })
        .catch(err => {
            console.log("kyo aaya ", err)
        })
    }
    render() {
        return (
            <div>
                <h1>Todo List......</h1>
                {
                    this.state.todos 
                    ? this.state.todos.map(t1 => <Todo key={t1.id} t1={t1}/>)
                    : <Spinner />
                }
            </div>
        )
    }
}
export default  withErrorHand(componentName, axios)