import React, { Component } from 'react'
import Signup from './Signup'
import Login from './Login'
export default class App extends Component {
  render() {
    return (
      <div>
        <h1>Todo5......</h1>
        <Signup />
        <Login />
      </div>
    )
  }
}
