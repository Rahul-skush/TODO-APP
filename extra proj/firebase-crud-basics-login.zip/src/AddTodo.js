import React, { Component } from 'react'
import axios from './axios'

export default class componentName extends Component {
    state = {
        txt: ''
    }
    onTxtChange = (e) => {
        this.setState({
            txt: e.target.value,            
        })
    }
    onAddHand = (e) => {
        e.preventDefault();
        const url = "todos.json";
        const data = {
            text: this.state.txt,
            status: "new"            
        }
        axios.post(url, data)
        .then(resp => {
            console.log(resp);
            this.setState({
                txt: ''
            })
        })
        .catch(err => {
            console.log(err);
        })
    }
    render() {
        return (
            <div>
                <input value={this.state.txt} onChange={this.onTxtChange} />
                <button onClick={this.onAddHand}>Add</button>
            </div>
        )
    }
}
