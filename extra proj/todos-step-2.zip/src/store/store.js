import todoRducers from './reducers/todo'
import {createStore, combineReducers, compose, applyMiddleware} from 'redux'
import thunk from 'redux-thunk'

const rootReducer = combineReducers({
    todo: todoRducers,
})

const enhanceComp = window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ || compose

const store = createStore(rootReducer, enhanceComp(applyMiddleware(thunk)));

export default store