import axios from 'axios'
const instance = axios.create({
    baseURL: "https://todotry2.firebaseio.com/",
})
export default instance;