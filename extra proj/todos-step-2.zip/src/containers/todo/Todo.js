import React, { Component } from 'react'
import {fetchTodos, addTodo} from '../../store/actions'
import {connect} from 'react-redux'
import TodoList from '../../components/todo/TodoList'
import AddTodo from '../../components/todo/AddTodo'


class Todo extends Component {    
    componentDidMount(){
        this.props.fetchTodos()
    }
    render() {
        return (
            <div>
                <AddTodo addTodo={this.props.addTodo} />
                <TodoList todos={this.props.todos} />
            </div>
        )
    }
}
const mapStateToProps = state => {
    return {
        todos: state.todo.todos,
        loading: state.todo.loading,
        error: state.todo.error,
    }
}
const mapDispatchToProps = dispatch => {
    return {
        fetchTodos: () => dispatch(fetchTodos()),
        addTodo: (txt) => dispatch(addTodo(txt)),
    }
}
export default connect(mapStateToProps, mapDispatchToProps)(Todo)