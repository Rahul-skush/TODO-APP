var events = require('events');
var eventEmitter = new events.EventEmitter();

eventEmitter.on('scream', ()=>{
    console.log("kaun bola????")
});
console.log(1)
console.log(2)
eventEmitter.emit('scream')
console.log(3)
