var uc = require("upper-case")
console.log(uc.upperCase("bla bla"));