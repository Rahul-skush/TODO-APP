var http = require("http");
var formidable = require("formidable")
var fs = require("fs");
http.createServer(function(req, res){
    if(req.url==="/fileupload"){
        res.writeHead(200, {"Content-Type":"text/html"});
        var form = new formidable.IncomingForm();
        form.parse(req, function(err, fields, files){
            var tmpName = files.at1.path;
            var name = "c:\\users\\com\\" + files.at1.name;            
            fs.rename(tmpName, name, function(res2){
                    console.log(res2);
                    res.end("Done!");    
            })
            console.log(tmpName);
            console.log(name);
        })
    } else {
        res.writeHead(200, {"Content-Type":"text/html"});
        res.write(`<form action="fileupload" method="post" enctype="multipart/form-data">
        <input type="file" name="at1" /></br>
        <input type="submit" value="Upload">
        </form>
        `);
        res.end();    
    }
}).listen(8081);