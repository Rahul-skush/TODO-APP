var http = require("http")
var fs = require("fs")
http.createServer(function(req, res){
    var data = "";
    if(req.url!=="/favicon.ico"){
        var fn = "." + req.url;
        fs.readFile(fn, function(err, data){
            if(err){
                res.writeHead(404, {"Content-Type":"text/html"});
                res.write("<h1>File not found!!</h1>");
                res.end();            
            } else {
                res.writeHead(200, {"Content-Type":"text/html"});
                res.write(data);
                res.end();            
            }
        })    
    }
}).listen(8081);