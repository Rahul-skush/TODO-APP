var nodemailer = require("nodemailer");
var trans = nodemailer.createTransport({
    service:"gmail",
    auth:{
        "user":"ec.smtp.test2@gmail.com",
        "pass":"surajsahu123"
    },
})
var ops = {
    from: "ec.smtp.test2@gmail.com",
    to:"aloya.effcon@gmail.com",
    subject: "hi from  node!",
    text: "bla bla"
}
trans.sendMail(ops, function(err, resp){
    if(err){
        console.log("Error::", err);
    } else {
        console.log("Done::", resp);
    }
})