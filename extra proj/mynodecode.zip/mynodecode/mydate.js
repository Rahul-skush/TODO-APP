exports.mydatefn = function(){
    return Date();
}