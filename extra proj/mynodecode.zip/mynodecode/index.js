var http = require("http")
var url = require("url")
var mydate = require('./mydate')
var mydatefn = require('./mydate').mydatefn
 
http.createServer(function(req, res){
    console.log(req.url)
    if(req.url==="/favicon.ico") {
        console.log("1::", mydate.mydatefn())
        console.log("2::", mydatefn())    
    }
    res.writeHead(200, {"Content-Type":"text/html"});
    res.write("<h1>bla bla 123</h1>");
    res.end();
}).listen(8081);