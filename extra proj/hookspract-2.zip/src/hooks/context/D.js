import React, { Component, useContext } from 'react'
import MyCtx from './MyCtx'

export default class D extends Component {   
    static contextType = MyCtx
    render() {
        console.log(this.context)
        return (
                 <h1>kk {this.context.count}</h1>
        )
    }
}
// D.contextType=MyCtx
// export default D
