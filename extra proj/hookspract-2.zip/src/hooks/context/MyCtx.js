import React from 'react'
const MyCtx = React.createContext({count: 10})
export default MyCtx