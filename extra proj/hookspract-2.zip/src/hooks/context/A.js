import React from 'react'
import B from './B'
import C from './C'
import D from './D'

export default function A(props) {
    return (
        <div>
            <B />
            <C />
            <D />
        </div>
    )
}
