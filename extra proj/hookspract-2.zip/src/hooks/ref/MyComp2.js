import React, {useImperativeHandle, useRef} from 'react'

function MyComp2(props, ref) {

    const ref1 = useRef(null);
    const ref2 = useRef(null);

    useImperativeHandle(ref, () => {
        return {
            focus1: ()=>{ref1.current.focus()},
            focus2: ()=>{ref2.current.focus()},
        }
    })
    
    return (
        <div>
            <input ref={ref1}/>
            <input ref={ref2} />
        </div>
    )
}
export default React.forwardRef(MyComp2)