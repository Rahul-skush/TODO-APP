import React from 'react'

function MyComp(props, ref) {
    return (
        <div>
            <input ref={ref}/>
        </div>
    )
}
export default React.forwardRef(MyComp)
