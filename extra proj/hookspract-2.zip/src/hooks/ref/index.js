import React, {useRef} from 'react'
import MyComp from './MyComp'
import MyComp2 from './MyComp2'

export default function Index() {
    // const myref = React.createRef(null);
    const myref = useRef(null);
    const m1 = () => {
        myref.current.focus1();
    }
    const m2 = () => {
        myref.current.focus2();
    }

    return (
        <div>
            {/* <input ref={myref}/> */}
            {/* <MyComp ref={myref}/> */}
            <MyComp2 ref={myref}/>
            <button onClick={m1}>Clk me1</button>
            <button onClick={m2}>Clk me2</button>
        </div>
    )
}
