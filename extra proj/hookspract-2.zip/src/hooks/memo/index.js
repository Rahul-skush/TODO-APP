import React, {useState, useMemo, useCallback} from 'react'
import MyComp from './MyComp'
import MyComp2 from './MyComp2'
import MyComp3 from './MyComp3'

export default function Index() {
    const [a, seta] = useState(0)
    const [b, setb] = useState(0)
    const [c, setc] = useState(0)
    const res =  useMemo(()=>{return  add(+a, +b)}, [a, b]);
    const MyCompMemo =  useMemo(()=>{return <MyComp a={a} b={b} />}, [a, b]);
    let myclk = null;
    useCallback(()=>{
        myclk = () => {}
    })
    return (
        <div>
            <h1>Sum is {res}</h1>
            <input value={a} onChange={(e)=>{seta(e.target.value)}} />
            <input value={b} onChange={(e)=>{setb(e.target.value)}} />
            <input value={c} onChange={(e)=>{setc(e.target.value)}} />
            <hr/>
            {MyCompMemo}
            {/* <MyComp a={a} b={b} /> */}
            <hr/>
            <MyComp2 a={a} b={b} />
            <MyComp3 clk={myclk} a={a} b={b} />
        </div>
    )
}
const add = (a, b) => {
    console.log("add call hua.....");
    return a+b;
}
