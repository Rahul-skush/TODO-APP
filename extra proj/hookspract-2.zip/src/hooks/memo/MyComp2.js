import React, {useEffect} from 'react'

function MyComp2(props) {
    useEffect(() => {
        console.log("MyComp   2   updated!!!.......");
    })
    return (
        <div>
            {+props.a + +props.b}
        </div>
    )
}
export default React.memo(MyComp2)
