import React, {useEffect} from 'react'

function MyComp3(props) {
    useEffect(() => {
        console.log("MyComp   3   updated!!!.......");
    })
    return (
        <div>
            {+props.a + +props.b}
        </div>
    )
}
export default React.memo(MyComp3)
