import React, {useReducer} from 'react'

export default function Index() {
    const reducer = (state, action) => {
        switch(action.type){
            case 'incr':
                return {count: state.count+1}
            case 'decr':
                return {count: state.count-action.no}
        }
    }
    // const m1 = () => {
    //     return {
    //         count: 90
    //     }
    // }
    // const [state, dispatch] = useReducer(reducer, {count:10}, m1)
    const [state, dispatch] = useReducer(reducer, {count:10})
    return (
        <div>
            <h1>{state.count}</h1>
            <button onClick={()=>{dispatch({type:'incr'})}}>+</button>
            <button onClick={()=>{dispatch({type:'decr', no: 5})}}>-</button>
        </div>
    )
}
