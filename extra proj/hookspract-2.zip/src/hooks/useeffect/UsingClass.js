import React, { Component } from 'react'

export default class UsingClass extends Component {
    componentDidMount(){
        console.log("componentDidMount...")
    }
    componentDidUpdate(){
        console.log("componentDidUpdate...")
    }
    componentWillUnmount(){
        console.log("componentWillUnmount...")
    }
    // shouldComponentUpdate(){
    //     return false;
    // }
    render() {
        console.log("i am render....")
        return (
            <div>
                <h1>class</h1>                
            </div>
        )
    }
}
