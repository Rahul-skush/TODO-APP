import React from 'react'
import MyForm from './MyForm'
export default function index() {
    return (
        <div>
            <h1>Bla Bla</h1>
            <MyForm />
        </div>
    )
}
