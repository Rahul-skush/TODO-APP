import React, { useState } from 'react'
import useInputValue from './useInputValue'

export default function MyForm() {
    // const [uname, setuname] = useState("Rahul")
    // const [age, setage] = useState(20)

    // const [uinfo, setuinfo] = useState({uname:"Rahul", age:20})

    // const onCh1 = (e) => {
    //     setuinfo({
    //         ...uinfo,
    //         [e.target.name]:e.target.value
    //     })
    // }

    // const [uname, setuname] = useState("Rahul")
    // const [age, setage] = useState(20)
    // const onCh2 = (e) => {
    //     let cmd = "set" + e.target.name;
    //     console.log(cmd + `("${e.target.value}")`)
    //     eval(cmd + `("${e.target.value}")`);
    // }

    const uname = useInputValue("Rahul");
    const age = useInputValue("20");

    return (
        <div>
            {/* <input  value={uname} onChange={(e)=>{setuname(e.target.value)}} />
            <input  value={age} onChange={(e)=>{setage(e.target.value)}}/> */}

            {/* <input name="uname"  value={uinfo.uname} onChange={onCh1} />
            <input name="age"  value={uinfo.age} onChange={onCh1}/> */}

            {/* <input name="uname"  value={uname} onChange={onCh2} />
            <input name="age"  value={age} onChange={onCh2}/> */}

            <input  {...uname} />
            <input  {...age}/>


        </div>
    )
}
