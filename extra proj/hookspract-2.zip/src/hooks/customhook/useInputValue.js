import {useState, useDebugValue} from 'react'

export default function useInputValue(initialValue) {
    const [state, setstate] = useState(initialValue)
    useDebugValue(state)
    return ({
        value: state,
        onChange: e => {setstate(e.target.value)}
    })
}
