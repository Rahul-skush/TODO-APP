import React from 'react'
import {connect} from 'react-redux'

function ListTodo(props) {
    return (
        <div>
            {props.todoList.map(t => {return <p key={t.id}>{t.text}</p>})}
        </div>
    )
}

const mapStateToProps = (state) => {
    return {
        todoList: state
    }
}

export default connect(mapStateToProps)(ListTodo)
