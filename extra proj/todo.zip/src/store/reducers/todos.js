import * as actionTypes from '../actions/actionTypes'

const addTodo = (state, action) => {
    return [
        ...state,
        {
           id: action.id,
           text: action.todoText 
        }
    ]
}

let initState = []
const todos = (state=initState, action) => {
    switch(action.type){
        case actionTypes.ADD_TODO:
            return addTodo(state, action)
        default: 
            return state
    }
}

export default todos;
