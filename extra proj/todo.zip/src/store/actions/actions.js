import * as actionTypes from './actionTypes'

let nid = 0;
export const addTodo = (txt) => {
    return {
        type: actionTypes.ADD_TODO,
        id: nid++,
        todoText: txt
    }
}