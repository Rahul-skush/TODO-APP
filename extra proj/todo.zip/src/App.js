import React from 'react'
import AddTodo from './AddTodo'
import ListTodo from './ListTodo'

export default function App() {
  return (
    <div>
      <h1>Todo App</h1>
      <AddTodo/>
      <ListTodo />
    </div>
  )
}
