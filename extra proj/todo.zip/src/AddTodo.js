import React, { Component } from 'react'
import * as actions from './store/actions/actions'
import {connect} from 'react-redux'

class AddTodo extends Component {
    state = {
        text: ''
    }
    onChangeHand = (e) => {
        this.setState({
            text: e.target.value
        })
    }
    render() {
        return (
            <div>
            <input onChange={this.onChangeHand} value={this.state.text} />
            <button onClick={()=>this.props.onAddHand(this.state.text)}>Add</button>                
            </div>
        )
    }
}

const mapDispatchToProps = dispatch => {
    
    return {
        onAddHand: (text) => {dispatch(actions.addTodo(text))}
    }
}

export default connect(null, mapDispatchToProps)(AddTodo)