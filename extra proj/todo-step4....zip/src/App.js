import React, { Component } from 'react'
import Todo from './containers/todo/Todo'
import Auth from './containers/auth/Auth';
import {connect} from 'react-redux'
class App extends Component {
  render() {
    return (
      <div>
        <h1>Todo App</h1>
        {
          this.props.isAuth
          ? <Todo />
          : <Auth />
        }
      </div>
    )
  }
}
const mapStateToProps = state => {
  return {
    isAuth: state.auth.token != null,
  }
}
export default connect(mapStateToProps)(App)
