import * as actTypes from './actionTypes'
import axios from 'axios'

export const login = (email, password) => {
    return dispatch => {
        const url = "https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=AIzaSyA-ow-_Omaf6P3Rx53id-MWTNesUXwPf2Q"
        const data = {
            email: email,
            password: password,
            returnSecureToken: true
        }
        axios.post(url, data)  
        .then(resp => {
            const token= resp.data.idToken;
            const userid = resp.data.localId;
            dispatch(loginSuccess(token,userid))
        })   
        .catch( err => {console.log(err)})  
    }
}
export const loginSuccess = (token,userid) => {
    return {
        type: actTypes.AUTH_LOGIN_SUCCESS,
        token,
        userid
    }
}

export const signup = (email, password) => {
    return dispatch => {
        const url = "https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=AIzaSyA-ow-_Omaf6P3Rx53id-MWTNesUXwPf2Q" 
        const data = {
            email: email,
            password: password,
            returnSecureToken: true
        }
        axios.post(url, data)  
        .then(resp => {
            const token= resp.data.idToken;
            const userid = resp.data.localId;
            dispatch(signupSuccess(token,userid))
        })   
        .catch( err => {console.log(err)})  

    }
}
export const signupSuccess = (token,userid) => {
    return {
        type: actTypes.AUTH_SIGNUP_SUCCESS,
        token,
        userid
    }
}
