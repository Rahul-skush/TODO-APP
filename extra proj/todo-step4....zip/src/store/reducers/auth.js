import * as actTypes from '../actions/actionTypes'
const initValues = {
    token: null,
    userid: null    
}

const signupSuccess = (state, action) => {
    return {
        ...state,
        token: action.token,
        userid: action.userid
    }
}
const loginSuccess = (state, action) => {
    return {
        ...state,
        token: action.token,
        userid: action.userid
    }
}

export const authReducers = (state = initValues, action) => {
    switch (action.type) {
        case actTypes.AUTH_SIGNUP_SUCCESS:
            return signupSuccess(state, action);
        case actTypes.AUTH_LOGIN_SUCCESS:
            return loginSuccess(state, action);
        default:
            return state
    }
}

export default authReducers