import React, { Component } from 'react'
export default function withErrorHand(OrigComp, axios) {

 
    return (class extends Component {
        state = {
            error: null,
            loading: false
        }

        // shouldComponentUpdate(nextProps, nextState, nextContext) {
        //     return nextState.error != this.state.error || nextState.loading != this.state.loading
        // }

        componentDidCatch(error){
            this.setState({
                error: error,
                loading: false
            })
        }

        constructor(){
            super()
            this.respInter = axios.interceptors.response.use(resp=> {
                this.setState({
                    loading: false,
                })                
                return resp;
            }, err => {
                this.setState({
                    error: err.message
                })                
            })            
            this.reqInter = axios.interceptors.request.use(req => {
                console.log(req)
                this.setState({
                    loading: true,
                })                
                return req;
            })

        }

        
        componentWillUnmount() {
            axios.interceptors.response.eject(this.respInter)
            axios.interceptors.response.eject(this.reqInter)
        }
        

        render() {
            if(this.state.error){
                return <h1 style={{color:'red'}}>{this.state.error}</h1>
            }
            else  if(this.state.loading){
                return <h1 style={{color:'blue'}}>Loading.....</h1>
            } else {
                return (
                    <OrigComp {...this.props} />
                )    
            }
        }
    }
    )
}
