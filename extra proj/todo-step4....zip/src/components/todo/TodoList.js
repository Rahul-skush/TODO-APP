import React, { useState } from 'react'
import Todo from './Todo'
export default function TodoList(props) {
    const [si, setsi] = useState("")
    return (
        <div>
            <h1>list.......</h1>
            <input type={si} onChange={(e)=>{setsi(e.target.value)}} />
            {
                props.todos 
                ? props.todos.map(t1 => 
                    {
                        if(t1.text.match(si)){
                            return <Todo completeTodo={props.completeTodo} deleteTodo={props.deleteTodo} 
                            updateTodo={props.updateTodo} 
                            key={t1.id} t1={t1}/>    
                        }
                        else {
                            return null;
                        }
                    })
                : <h1>Loading....</h1>
            }
        </div>
    )
}
