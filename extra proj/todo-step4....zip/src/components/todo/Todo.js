import React, { useState } from 'react'

export default function Todo(props) {

    const [txt, settxt] = useState(props.t1.text)
    
    const onCompHand = () => {
        props.completeTodo(props.t1);
    }
    const onDelHand = () => {
        props.deleteTodo(props.t1);
    }
    const onUpHand = () => {
        props.t1.text = txt
        props.updateTodo(props.t1);
    }
    return (
        <div>
            <p>{props.t1.text}
            <input value={txt} onChange={(e)=>{settxt(e.target.value)}} />
            <button onClick={onUpHand}>Update</button>
            <button onClick={onCompHand}>Complete</button>
            <button onClick={onDelHand}>Delete</button>
            </p>
        </div>
    )
}
