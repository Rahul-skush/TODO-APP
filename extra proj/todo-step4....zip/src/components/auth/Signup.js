import React, { useState } from 'react'

export default function Signup(props) {
    const [email, setemail] = useState("")
    const [password, setpassword] = useState("")
    const onClkHand = () => {
        props.signUp(email, password)
    } 
    return (
        <div>
            <input value={email} onChange={(e)=>{setemail(e.target.value)}} type="email" />
            <input value={password} onChange={(e)=>{setpassword(e.target.value)}} type="password" />
            <button onClick={onClkHand}>Signup</button>
        </div>
    )
}
