import React, { useState } from 'react'

export default function Login(props) {
    const [email, setemail] = useState("")
    const [password, setpassword] = useState("")
    const onClkHand = () => {
        props.login(email, password)
    } 
    return (
        <div>
            <input value={email} onChange={(e)=>{setemail(e.target.value)}} type="email" />
            <input value={password} onChange={(e)=>{setpassword(e.target.value)}} type="password" />
            <button onClick={onClkHand}>Login</button>
        </div>
    )
}
