import React, { Component } from 'react'
export default function withErrorHand(OrigComp, axios) {
    return (class extends Component {
        state = {
            error: null
        }

        componentDidCatch(error){
            this.setState({
                error: error
            })
        }

        constructor(){
            super()
            this.respInter = axios.interceptors.response.use(resp=>resp, err => {
                this.setState({
                    error: err.message
                })                
            })
        }

        
        componentWillUnmount() {
            axios.interceptors.response.eject(this.respInter)
        }
        

        render() {
            if(this.state.error){
                return <h1 style={{color:'red'}}>{this.state.error}</h1>
            }
            else {
                return (
                    <OrigComp {...this.props} />
                )    
            }
        }
    }
    )
}
