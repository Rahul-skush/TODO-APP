import React, { Component } from 'react'
import {fetchTodos, addTodo, completeTodo, updateTodo, deleteTodo} from '../../store/actions'
import {connect} from 'react-redux'
import TodoList from '../../components/todo/TodoList'
import AddTodo from '../../components/todo/AddTodo'
import axios from '../../axios'
import withErrorHand from '../../hoc/withErrorHand'


class Todo extends Component {    
    componentDidMount(){
        this.props.fetchTodos()
    }
    render() {
        return (
            <div>
                <AddTodo addTodo={this.props.addTodo} />
                <TodoList updateTodo={this.props.updateTodo} deleteTodo={this.props.deleteTodo} completeTodo={this.props.completeTodo} todos={this.props.todos} />
            </div>
        )
    }
}
const mapStateToProps = state => {
    return {
        todos: state.todo.todos,
        loading: state.todo.loading,
        error: state.todo.error,
    }
}
const mapDispatchToProps = dispatch => {
    return {
        fetchTodos: () => dispatch(fetchTodos()),
        addTodo: (txt) => dispatch(addTodo(txt)),
        completeTodo: (t1) => dispatch(completeTodo(t1)),
        deleteTodo: (t1) => dispatch(deleteTodo(t1)),
        updateTodo: (t1) => dispatch(updateTodo(t1)),
    }
}
export default connect(mapStateToProps, mapDispatchToProps)(withErrorHand(Todo, axios))