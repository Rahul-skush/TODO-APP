import React, { Component } from 'react'

export default class componentName extends Component {
    state = {
        txt: ''
    }
    onChangeHand = (e) => {
        this.setState({
            [e.target.name]:e.target.value
        })
    }
    onAddHand = (e) => {
        e.preventDefault();
        this.props.addTodo(this.state.txt);
        this.setState({
            txt: ''
        })
    }
    render() {
        return (
            <div>
                <input name="txt" value={this.state.txt} onChange={this.onChangeHand} />
                <button onClick={this.onAddHand}>Add</button>
            </div>
        )
    }
}
