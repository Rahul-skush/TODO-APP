import * as actTypes from './actionTypes'
import axios from '../../axios'

export const fetchTodos = (userid, token) => {
    return (dispatch) => {
        dispatch(todosStart());
        let url = "todos.json";
        axios.get(url)
        .then(resp => {
            let mytodos = []
            Object.keys(resp.data).forEach(e => {
                mytodos.push({
                    id: e,
                    ...resp.data[e]
                })
            })
            dispatch(fetchTodosSuccess(mytodos));
        })
        .catch(err => {
            dispatch(todosFail(err.message));
        })
        
    }
}

export const todosStart = () => {
    return {
        type: actTypes.TODOS_START,
    }
}

export const fetchTodosSuccess = (todos) => {
    return {
        type: actTypes.FETCH_TODOS_SUCCESS,
        todos: todos
    }
}

export const todosFail = (error) => {
    return {
        type: actTypes.TODOS_FAIL,
        error: error
    }
}

export const addTodo = (txt) => {
    return (dispatch) => {
        dispatch(todosStart());
        let url = "todos.json";
        let t1 = {
            text: txt,
            status: "new",
        }
        axios.post(url, t1)
        .then(resp => {
            console.log(resp);
            console.log(t1);
            t1.id = resp.data.name;
            dispatch(addTodosSuccess(t1));
        })
        .catch(err => {
            dispatch(todosFail(err.message));
        })
        
    }
}

export const addTodosSuccess = (t1) => {
    return {
        type: actTypes.ADD_TODOS_SUCCESS,
        t1: t1
    }
}


export const completeTodo = (t1) => {
    return (dispatch) => {
        dispatch(todosStart());
        let url = `todos/${t1.id}.json`;
        t1.status="complete";
        axios.patch(url, t1)
        .then(resp => {
            console.log(resp);
            dispatch(completeTodosSuccess(t1));
        })
        .catch(err => {
            dispatch(todosFail(err.message));
        })
        
    }
}

export const completeTodosSuccess = (t1) => {
    return {
        type: actTypes.COMPLETE_TODOS_SUCCESS,
        t1: t1
    }
}