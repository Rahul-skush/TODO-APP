import React from 'react'

export default function Todo(props) {
    const onCompHand = () => {
        props.completeTodo(props.t1);
    }
    return (
        <div>
            <p>{props.t1.text}
            <button onClick={onCompHand}>X</button>
            </p>
        </div>
    )
}
