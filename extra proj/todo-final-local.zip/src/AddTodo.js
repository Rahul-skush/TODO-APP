import React, { Component } from 'react'
import {connect} from 'react-redux'
import {addTodo} from './store/actions/actions'

class AddTodo extends Component {
    state = {
        text: ''
    }
    onChangeHand = (e) => {
        this.setState({
            text: e.target.value
        })        
    }
    render() {
        return (
            <div>
                <h1>Add Todo</h1>
                <input onChange={this.onChangeHand} value={this.state.text} />
                <button onClick={()=>{this.props.addTodo(this.state.text);this.setState({text:''})}} >Clk Me</button>
            </div>
        )
    }
}

const mapDispatchToProps = dispatch => {
    return {
        addTodo : (text) => {dispatch(addTodo(text))}
    }
}
export default connect(null, mapDispatchToProps)(AddTodo)