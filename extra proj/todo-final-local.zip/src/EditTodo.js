import React, { Component } from 'react'
import {connect} from 'react-redux'
import {editTodo, changeMode} from './store/actions/actions'

class EditTodo extends Component {
    // constructor(props){
    //     super(props);
    //     this.state = {
    //         text: props.selectedTodo.text
    //     }
    // }
        state = {
            text: '',
            id: null,
        }

        static getDerivedStateFromProps(nextProps, prevState) {
            if(nextProps.selectedTodo){
                if(nextProps.selectedTodo.id != prevState.id){
                    // console.log("dhoka....")
                    return {
                        ...prevState,
                        text: nextProps.selectedTodo.text,
                        id: nextProps.selectedTodo.id
                    }    
                }
            }
            return null;
        }
    onChangeHand = (e) => {
        // console.log(e.target.value)
        this.setState({
            text: e.target.value
        })        
    }
    render() {
        return (
            <div>
                <h1>Edit Todo</h1>
                <input onChange={this.onChangeHand} value={this.state.text} />
                <button onClick={()=>{this.props.editTodo(this.state.id ,this.state.text);this.setState({text:''})}} >Clk Me</button>
                <button onClick={()=>{this.props.cancleEdit()}} >Cancle</button>
            </div>
        )
    }
}

const mapDispatchToProps = dispatch => {
    return {
        editTodo : (id, text) => {dispatch(editTodo(id,text))},
        cancleEdit : () => {dispatch(changeMode(false))}
    }
}
const mapStateToProps = state => {
    return {
        selectedTodo: state.selectedTodo
    }
}
export default connect(mapStateToProps, mapDispatchToProps)(EditTodo)