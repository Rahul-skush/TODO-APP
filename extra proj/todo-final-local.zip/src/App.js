import React, { Component } from 'react'
import AddTodo from './AddTodo'
import EditTodo from './EditTodo'
import ListTodos from './ListTodos'
import {connect} from 'react-redux'
import { runInThisContext } from 'vm';

class App extends Component {
  render() {
    let out = <AddTodo />;
    return (
      <div>
      <h1>kake</h1>
      {this.props.editMode? <EditTodo /> : <AddTodo /> }      
      <ListTodos />
      </div>
    )
  }
}

const mapStateToProps = state => {
  return {
    editMode: state.editMode,
    id: state.id
  }
}
const mapDispatchToProps = null;
export default connect(mapStateToProps, mapDispatchToProps)(App)

