import React from 'react'
import {connect} from 'react-redux'
import {completeTodo, clearTodos, changeMode} from './store/actions/actions'

function ListTodo(props) {
    return (
        <div>
            <h1>List todo....</h1>
            <button onClick={()=>props.clearTodos()}>Clear All</button>
            {props.todoList.map(t1 => <p onClick={()=>{props.changeMode(true, t1.id)}} key={t1.id}>{t1.text} <button onClick={()=>props.completeTodo(t1.id)}>X</button></p>)}
        </div>
    )
}

const mapStateToProps = state => {
    return {
        todoList: state.listTodos
    }
}
const mapDispatchToProps = dispatch =>{
    return {
        completeTodo: (id) =>  {dispatch(completeTodo(id))},
        clearTodos: () =>  {dispatch(clearTodos())},
        changeMode: (mode, id) =>  {dispatch(changeMode(mode, id))},
    }
}
export default connect(mapStateToProps, mapDispatchToProps)(ListTodo)