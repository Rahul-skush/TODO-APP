import * as actTypes from '../actions/actionTypes'

let initState = {
    listTodos:[],
    editMode: false,
    selectedTodo: null,
}
const addTodo = (state, action) => {
    return {
        ...state,
        listTodos: [
            ...state.listTodos,
            {
                id: action.id,
                text: action.text
            }
        ]
    }
}


const editTodo = (state, action) => {
    // let updatedTodos = state.listTodos.filter(e => e.id !== action.id);
    // let changedTodo = state.listTodos.find(e => e.id == action.id);
    // let index = state.listTodos.findIndex((e => e.id == action.id));
    // changedTodo.text=action.text;
    // updatedTodos.splice(index, 0, changedTodo)
    let updatedTodos = [...state.listTodos];
    let changedTodo = state.listTodos.find(e => e.id == action.id);
    changedTodo.text=action.text;
    return {
        ...state,
        listTodos:updatedTodos,
        selectedTodo: null,
        editMode: false
    }
}



const completeTodo = (state, action) => {
    // let updatedTodos = []
    // state.listTodos.forEach(e => {
    //     if(e.id != action.id){
    //         updatedTodos.push(e);
    //     }
    // });
    let updatedTodos = state.listTodos.filter(e => e.id !== action.id)
    return {
        ...state,
        listTodos: updatedTodos
    }
}

const clearTodos = (state, action) => {
    let updatedTodos = []
    return {
        ...state,
        listTodos: updatedTodos
    }
}

const changeMode = (state, action) => {
    let selectedTodo = null;
    if(action.mode){
        selectedTodo = state.listTodos.find((e)=>e.id==action.id)
    }
    return {
        ...state,
        editMode: action.mode,
        selectedTodo: selectedTodo
    }
}


export const todoReducer = (state = initState, action) => {
    switch (action.type) {
        case actTypes.ADD_TODO:
            return addTodo(state, action)
        case actTypes.COMPLETE_TODO:
            return completeTodo(state, action)
        case actTypes.CLEAR_TODOS:
            return clearTodos(state, action)
        case actTypes.CHANGE_MODE:
            return changeMode(state, action)
        case actTypes.EDIT_TODO:
            return editTodo(state, action)
        default:
            return state
    }
}

export default todoReducer