import * as actTypes from './actionTypes'

let nid = 0;
export const addTodo = (text) => {
    return {
        type: actTypes.ADD_TODO,
        id: nid++,
        text: text
    }
}

export const editTodo = (id, text) => {
    return {
        type: actTypes.EDIT_TODO,
        id: id,
        text: text
    }
}

export const completeTodo = (id) => {
    return {
        type: actTypes.COMPLETE_TODO,
        id: id
    }
}

export const clearTodos = () => {
    return {
        type: actTypes.CLEAR_TODOS,
    }
}

export const changeMode = (mode, id=null) => {
    return {
        type: actTypes.CHANGE_MODE,
        mode: mode,
        id: id
    }
}