export const ADD_TODO = "ADD_TODO"
export const COMPLETE_TODO = "COMPLETE_TODO"
export const CLEAR_TODOS = "CLEAR_TODOS"
export const CHANGE_MODE = "CHANGE_MODE"
export const EDIT_TODO = "EDIT_TODO"




