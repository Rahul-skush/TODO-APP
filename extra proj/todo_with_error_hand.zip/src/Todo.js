import React from 'react'

export default function Todo(props) {
    return (
        <div>
            <h1>{props.t1.text}</h1>
        </div>
    )
}
