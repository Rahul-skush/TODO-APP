import React, { Component } from 'react'
import {fetchTodos} from '../../store/actions'
import {connect} from 'react-redux'
import TodoList from '../../components/todo/TodoList'

class Todo extends Component {    
    componentDidMount(){
        this.props.fetchTodos()
    }
    render() {
        return (
            <div>
                <TodoList todos={this.props.todos} />
            </div>
        )
    }
}
const mapStateToProps = state => {
    return {
        todos: state.todo.todos,
        loading: state.todo.loading,
        error: state.todo.error,
    }
}
const mapDispatchToProps = dispatch => {
    return {
        fetchTodos: () => dispatch(fetchTodos())
    }
}
export default connect(mapStateToProps, mapDispatchToProps)(Todo)