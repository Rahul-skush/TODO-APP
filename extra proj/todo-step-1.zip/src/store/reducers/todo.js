import * as actTypes from '../actions/actionTypes'


const initValues = {
    todos: null,
    loading: false,
    error: null,
    selectedTodo: null
}

const fetchTodosStart = (state  , action) => {
    return {
        ...state,
        loading: true,
        error: null,
    }
}

const fetchTodosSuccess = (state  , action) => {
    return {
        ...state,
        loading: false,
        todos: action.todos   
    }
}

const fetchTodosFail = (state  , action) => {
    return {
        ...state,
        loading: false,
        error: action.error   
    }
}

const todoReducers = (state = initValues , action) => {
    switch (action.type) {
        case actTypes.FETCH_TODOS_START:
            return fetchTodosStart(state, action)
        case actTypes.FETCH_TODOS_SUCCESS:
            return fetchTodosSuccess(state, action)
        case actTypes.FETCH_TODOS_FAIL:
            return fetchTodosFail(state, action)
        default:
            return state
    }
}

export default todoReducers;    