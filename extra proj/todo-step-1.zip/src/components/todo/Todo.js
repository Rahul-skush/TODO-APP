import React from 'react'

export default function Todo(props) {
    return (
        <div>
            <p>{props.t1.text}</p>
        </div>
    )
}
