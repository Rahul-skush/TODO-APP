import React, { Component } from 'react'
import {fetchTodos, addTodo, completeTodo, updateTodo, deleteTodo} from '../../store/actions'
import {connect} from 'react-redux'
import TodoList from '../../components/todo/TodoList'
import AddTodo from '../../components/todo/AddTodo'
import axios from '../../axios'
import withErrorHand from '../../hoc/withErrorHand'


class Todo extends Component {    
    componentDidMount(){
        this.props.fetchTodos(this.props.userid)
    }
    render() {
        return (
            <div>
                <AddTodo  addTodo={this.props.addTodo} userid={this.props.userid} />
                <TodoList updateTodo={this.props.updateTodo} deleteTodo={this.props.deleteTodo} completeTodo={this.props.completeTodo} todos={this.props.todos} />
            </div>
        )
    }
}
const mapStateToProps = state => {
    return {
        todos: state.todo.todos,
        loading: state.todo.loading,
        error: state.todo.error,
        userid: state.auth.userid,
        token: state.auth.token
    }
}
const mapDispatchToProps = dispatch => {
    return {
        fetchTodos: (userid) => dispatch(fetchTodos(userid, 'a')),
        addTodo: (txt, userid) => dispatch(addTodo(txt, userid, 'a')),
        completeTodo: (t1) => dispatch(completeTodo(t1, 'a')),
        deleteTodo: (t1) => dispatch(deleteTodo(t1, 'a')),
        updateTodo: (t1) => dispatch(updateTodo(t1, 'a')),
    }
}
export default connect(mapStateToProps, mapDispatchToProps)(withErrorHand(Todo, axios))