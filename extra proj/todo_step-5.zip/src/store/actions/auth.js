import * as actTypes from './actionTypes'
import axios from 'axios'

export const login = (email, password) => {
    return dispatch => {
        const url = "https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=AIzaSyA-ow-_Omaf6P3Rx53id-MWTNesUXwPf2Q"
        const data = {
            email: email,
            password: password,
            returnSecureToken: true
        }
        axios.post(url, data)  
        .then(resp => {
            const token= resp.data.idToken;
            const userid = resp.data.localId;
            dispatch(loginSuccess(token,userid))
        })   
        .catch( err => {console.log(err)})  
    }
}

export const autoLoginCheck = () => {
    const token = localStorage.getItem("token")
    const userId = localStorage.getItem("userid")
    if(token && userId){
        return loginSuccess(token, userId);
    }
    return {
        type: actTypes.DO_NOTHING
    }
}

export const logout = () => {
    localStorage.removeItem("token")
    localStorage.removeItem("userid")
    return {
        type: actTypes.AUTH_LOGOUT,
    }
}


export const loginSuccess = (token,userid) => {
    localStorage.setItem("token", token)
    localStorage.setItem("userid", userid)
    return {
        type: actTypes.AUTH_LOGIN_SUCCESS,
        token,
        userid
    }
}

export const signup = (email, password) => {
    return dispatch => {
        const url = "https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=AIzaSyA-ow-_Omaf6P3Rx53id-MWTNesUXwPf2Q" 
        const data = {
            email: email,
            password: password,
            returnSecureToken: true
        }
        axios.post(url, data)  
        .then(resp => {
            const token= resp.data.idToken;
            const userid = resp.data.localId;
            dispatch(signupSuccess(token,userid))
        })   
        .catch( err => {console.log(err)})  

    }
}
export const signupSuccess = (token,userid) => {
    localStorage.setItem("token", token)
    localStorage.setItem("userid", userid)
    return {
        type: actTypes.AUTH_SIGNUP_SUCCESS,
        token,
        userid
    }
}
