var  MongoClient =  require("mongodb").MongoClient;
var url = "mongodb://localhost:27017/mydb3/";
MongoClient.connect(url, function(err, db){
    if(err) throw err;
    var dbo = db.db("mydb3");
    dbo.collection("students").aggregate([
        {
            $lookup: {
                from: "branch",
                localField: "branch_id",
                foreignField: "_id",
                as: "branch"
            }
        }
    ])
    .toArray(function(err, res){
        if(err) throw err;
        console.log(JSON.stringify(res));
    })
})
