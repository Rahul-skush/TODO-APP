var  MongoClient =  require("mongodb").MongoClient;
var url = "mongodb://localhost:27017/mydb3/";
MongoClient.connect(url, function(err, db){
    if(err) throw err;
    var dbo = db.db("mydb3");
    var data = [
        {"_id": 1,  name: 'CS', hod: 'abc'},
        {"_id": 2,  name: 'IT', hod: 'kk'},
        {"_id": 3,  name: 'Elex', hod: 'bla'}
      ];
    dbo.collection("branch").insertMany(data, function(err, res){
        if(err) throw err;
        console.log(res);
    })

    data = [
        {"_id": 1,  name: 'Ajay', branch_id: 1},
        {"_id": 2,  name: 'Akash', branch_id: 2},
      ];
    dbo.collection("students").insertMany(data, function(err, res){
        if(err) throw err;
        console.log(res);
    })
    console.log("inserted!!");
})
