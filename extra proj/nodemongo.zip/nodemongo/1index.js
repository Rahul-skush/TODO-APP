// var mongo = require("mongodb")
var  MongoClient =  require("mongodb").MongoClient;
var url = "mongodb://localhost:27017/mydb3";
MongoClient.connect(url, function(err, db){
    if(err) throw err;
    db.close()
    console.log("created!!");
})
