var  MongoClient =  require("mongodb").MongoClient;
var url = "mongodb://localhost:27017/mydb3/";
MongoClient.connect(url, function(err, db){
    if(err) throw err;
    var dbo = db.db("mydb3");
    var query = {name: /^v/i}
    var nd = {$set:{"address":"Raipur"}}
    dbo.collection("customers").updateMany(query, nd, function(err, res){
        if(err) throw err;
        console.log(res);
    })
    // console.log("bla bla!!");
})
