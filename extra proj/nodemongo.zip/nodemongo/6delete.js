var  MongoClient =  require("mongodb").MongoClient;
var url = "mongodb://localhost:27017/mydb3/";
MongoClient.connect(url, function(err, db){
    if(err) throw err;
    var dbo = db.db("mydb3");
    var query = {name: /^v/i}
    dbo.collection("customers").deleteMany(query, function(err, res){
        if(err) throw err;
        console.log("done::", res);
    })
})
