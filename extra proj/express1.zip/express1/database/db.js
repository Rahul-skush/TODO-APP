
function insert(data){
    var  MongoClient =  require("mongodb").MongoClient;
    var url = "mongodb://localhost:27017/mydb3/";
    MongoClient.connect(url, function(err, db){
        if(err) throw err;
        var dbo = db.db("mydb3");
        dbo.collection("users").insertOne(data, function(err, res){
            if(err) throw err;
        })
    })    
}
module.exports = {
    insert,
};