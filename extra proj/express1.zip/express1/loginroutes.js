var express = require("express")
var router = express.Router()

router.get("/login", function(req,res){
    res.send("<h1>Login</h1>");
})
router.get("/register", function(req,res){
    res.send("<h1>Register....</h1>");
})

module.exports = router;
