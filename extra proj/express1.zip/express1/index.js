var express = require("express")
var app = express()
app.get("/", function(req,res){
    res.send("<h1>bla bla</h1>");
})
app.post("/", function(req,res){
    res.send("<h1>from post....</h1>");
})
app.get("/about", function(req,res){
    res.send("<h1>about us.....</h1>");
})
app.route("/contact").get(function(req,res){
    res.send("<h1>Contact us.....</h1>");
})
app.all("/home", function(req,res){
    res.send("<h1>I am home</h1>");
})


var server = app.listen(8081, function(){
    console.log("Server started ");
});