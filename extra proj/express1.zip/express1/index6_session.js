var express = require("express")
var cookieParser = require('cookie-parser');
var session = require('express-session');
var app = express()
app.use(cookieParser());
app.use(session({secret: "key for encr 8798798", resave: true,
saveUninitialized: true}));
app.get("/home", function(req,res){
    if(req.session.name){
        res.send(`<h1>Welcome ${req.session.name}</h1>`); 
    } else {
        res.send(`<h1>Please Login!!</h1>`);        
    }
})
app.get("/login/:name", function(req,res){
    req.session.name=req.params.name;    
    res.send(`<h1>Thenks for login!`);
})
app.get("/logout", function(req,res){
    req.session.name=null;    
    res.send(`<h1>Thenks Tata!!!`);
})

var server = app.listen(8081);