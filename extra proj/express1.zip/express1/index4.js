var express = require("express")
var app = express()
// app.get("/:id", function(req,res){
//     res.send(`<h1>Details of student  ${req.params.id} </h1>`);
// })

app.get("/:id([0-9]{5})", function(req,res){
    res.send(`<h1>Details of student  ${req.params.id} </h1>`);
})

// app.get("/secure/*", function(req,res){
//     res.send(`<h1>Check for login......</h1>`);
// })


app.get("/student/:name/:rn", function(req,res){
    res.send(`<h1>Details of student  ${req.params.name} ${req.params.rn}</h1>`);
})

var server = app.listen(8081, function(){
    console.log("Server started ");
});