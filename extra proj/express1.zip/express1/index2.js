var express = require("express")
var app = express()
app.set("view engine", "pug")
app.get("/about", function(req,res){
    res.render("index", {title: "About US", msg:"Bla bla bla"});
})
app.route("/contact").get(function(req,res){
    res.render("index", {title: "Contact", msg:"9998889998"});
})
var server = app.listen(8081);