var express = require("express")
var app = express()
// app.use(express.bodyParser());
// app.use(express.urlencoded());
app.use(function(req, res, next){
    res.write("<h1>Start.......</h1>");    
    next();
    res.write("<h1>End.......</h1>");    
    res.end();
})
app.use("/secure/*" ,function(req, res, next){
    if(req.query.token){
        next();
    } else {
        res.write("<h1>Please login first.......</h1>");    
    }
})

app.get("/secure/home", function(req,res){
    res.write("<h1>home.....</h1>");
})
app.get("/about", function(req,res){
    res.write("<h1>about us.....</h1>");
})
app.get("/contact", function(req,res){
    res.write("<h1>Contact.....</h1>");
})
var server = app.listen(8081);