var express = require("express")
var cookieParser = require('cookie-parser');
var app = express()
app.use(cookieParser());

app.get("/search/:si?", function(req,res){
    console.log(req.params.si);
    if(req.params.si){
        // res.cookie('si', req.params.si);
        // res.cookie('si', req.params.si, {maxAge: 5*24*60*60*1000});
        // res.clearCookie('foo');
        res.cookie('si', req.params.si, {maxAge: 10*1000});
        res.send(`<h1>You searched ${req.params.si}</h1>`);    
    } else if(req.cookies.si) {
        res.send(`<h1>Cookie::: You searched ${req.cookies.si}</h1>`);    
    } else {
        res.send(`<h1>whatever is populer</h1>`);    
    }
})
var server = app.listen(8081);