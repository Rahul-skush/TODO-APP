import React from 'react'

export default function Spinner() {
    return (
        <div>
            <h1>Loading.......</h1>
        </div>
    )
}
