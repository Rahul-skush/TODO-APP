import React, { Component } from 'react'
import axios from 'axios'
import Spinner from './Spinner'
export default class componentName extends Component {
  state = {
    todos: null,
    error: null
  }
  componentDidMount(){
    let url = "https://todotry-33555.firebaseio.com/todos.json";    
    axios(url)
    .then( resp => {
      console.log(resp.data);
      let mytodos = []
      Object.keys(resp.data).forEach(e => {
        mytodos.push({
          id: e,
          ...resp.data[e]
        })
      })
      console.log(mytodos);

      this.setState({
        todos: mytodos,
      })
    })
    .catch( err => {
      this.setState({
        error: err.message
      })
      console.log(err.message)
    })
  }
  render() {
    let out = "";
    if(this.state.error){
      out = <p style={{color:'red'}}>{this.state.error}</p>
    }
    return (
      <div>
        <h1>kake.....</h1>
        { this.state.todos 
          ? this.state.todos.map(t1 =>  <p key={t1.id}>{t1.text}</p>) 
          : <Spinner/>
        }
        {out}
      </div>
    )
  }
}
