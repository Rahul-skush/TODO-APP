import React, { Component } from 'react'
import axios from 'axios'
export default class Signup extends Component {
    state ={
        email: '',
        password: ''
    }
    onChHand = (e) => {
        this.setState({
            [e.target.name]: e.target.value
        })
    }
    onSubHand = (e) => {
        e.preventDefault();
        // let url = "https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=AIzaSyDIgCMuQgPLcy349h0lmJPMXsLoP8xwRSI";
        const data = {
            email: this.state.email,
            password: this.state.password,
            // returnSecureToken: true
        }
        let url="https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=AIzaSyA-ow-_Omaf6P3Rx53id-MWTNesUXwPf2Q"
        axios.post(url, data)
        .then(resp => {
            console.log(resp)
            localStorage.setItem("userid",  resp.data.localId);
            localStorage.setItem("token",  resp.data.idToken);
            this.props.onLoginChange(resp.data.idToken, resp.data.localId)
        })
        .catch(err=>{
            console.log(err)
        })

    }
    render() {
        return (
            <div>
                <input onChange={this.onChHand} name="email" type= "email" value={this.state.email} />
                <input onChange={this.onChHand} name="password" type="password" value={this.state.password} />
                <button onClick={this.onSubHand}>Login</button>
            </div>
        )
    }
}
