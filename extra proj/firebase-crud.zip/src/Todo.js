import React, { useState } from 'react'
import axios from './axios'
export default function Todo(props) {
    const [txt, settxt] = useState(props.t1.text)
    const upHand0 = (e) => {
        const url = `todos/${props.t1.id}/.json`;
        const data = {
            ...props.t1,
            text: txt,
        };
        axios.patch(url, data)
        .then(resp => {
            console.log(resp);
        })
        .catch(err => {
            console.log(err);
        })
    }
    const upHand = (e) => {
        const url = `todos/${props.t1.id}/.json`;
        // const url = `todos.json`;
        const data = {
            text: props.t1.text,
            status: "complete"
        };
        // const data= props.t1
        data.status = "complete"
        axios.patch(url, data)
        .then(resp => {
            console.log(resp);
        })
        .catch(err => {
            console.log(err);
        })
    }

    const upHand2 = (e) => {
        const url = `todos/${props.t1.id}/.json`;
        axios.delete(url)
        .then(resp => {
            console.log(resp);
        })
        .catch(err => {
            console.log(err);
        })
    }

    return (
        <div>
            <h1>{props.t1.text} 
            <input value={txt} onChange={(e)=>{settxt(e.target.value)}} />
            <button onClick={upHand0}>Up</button>
            <button onClick={upHand}>X</button>
            <button onClick={upHand2}>XX</button></h1>
        </div>
    )
}
