import React, { Component } from 'react'

export default class AppTry1 extends Component {
    state = {
        items: [],
        txt: ''
    }
    onChHand = (e) => {
        this.setState({
            txt: e.target.value
        })
    }
    onSaveHand = (e) => {
        this.setState((prevState) => {
            return {
                items: [...prevState.items, prevState.txt],
                txt: ''
            }
        }
        )
    }
    render() {
        return (
            <div>
                <h1>kake</h1>
                <input value={this.state.txt} onChange={this.onChHand} />
                <button onClick={this.onSaveHand}>Add</button>
                {this.state.items.map(e => <p>{e}</p>)}
            </div>
        )
    }
}
