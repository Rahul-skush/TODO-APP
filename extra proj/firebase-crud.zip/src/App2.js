import React, { Component } from 'react'
import TodoList from './TodoList'
import AddTodo from './AddTodo'
export default class App extends Component {
  render() {
    return (
      <div>
        <h1>Todo5......</h1>
        <AddTodo token={this.props.token} userid={this.props.userid}/>
        <TodoList token={this.props.token} userid={this.props.userid}/>
      </div>
    )
  }
}
