import React, { Component } from 'react'
export default function withErrorHand(OrigComp, axios=null) {
    return  class extends Component {
        state = {
            error: null
        }
        componentDidCatch(err){
            this.setState({
                error: err
            })
        }
        constructor(){
            super()
            this.respint = axios.interceptors.response.use(resp=>resp, err=>{
                console.log("aaaya.....", err.message)
                this.setState({
                    error: err.message
                })
                // return err;
            })
        }
        componentWillUnmount(){
            axios.interceptors.response.eject(this.respint)
        }
        render() {
            if(this.state.error){
                return <p style={{color:'red'}}>{this.state.error}</p>
            }
            else {
                return (
                    <OrigComp {...this.props} />
                )    
            }
        }
    }
    
}
