import React, { Component } from 'react'
import Signup from './Signup'
import Login from './Login'
import App2 from './App2'
export default class App extends Component {

  state = {
    token: null,
    userid: null,
    isAuth: false
  }

  componentDidMount(){
    let token = localStorage.getItem("token")
    let userid = localStorage.getItem("userid")
    if(token){
      this.loginChange(token, userid)
    }
  }

  loginChange=(token, userid)=>{
    console.log("aaaya.....")
    this.setState({
      token: token,
      userid: userid,
      isAuth: token != null
    })
  }

  onLogoutHand = () => {
    localStorage.removeItem("token")
    localStorage.removeItem("userid")
    this.loginChange(null, null)
  }

  render() {
    return (
      <div>
        <h1>Todo5......</h1>
        {
          this.state.isAuth 
        ? 
        <>
        <button onClick={this.onLogoutHand}>Logout</button>
        <App2 token={this.state.token} userid={this.state.userid}/> 
        </>
        : 
        <>
        <Signup />
        <Login onLoginChange={this.loginChange} />
        </>
        }
      </div>
    )
  }
}
