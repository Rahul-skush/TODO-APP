import React from 'react'

export default function About() {
    return (
        <div>
            <h1>I am Home page...</h1>
        </div>
    )
}
