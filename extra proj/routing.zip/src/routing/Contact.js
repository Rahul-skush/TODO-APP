import React from 'react'

import {Switch, Route, Redirect} from 'react-router'
import {NavLink} from 'react-router-dom'
import './nav.css'
import Home from './Home'
import About from './About'

export default function Contact() {
    return (
        <div>
            <h1>I am Contact page...</h1>
            <div>
            <nav>
            <NavLink activeClassName="act" to='/contact/home'>Home</NavLink>{' '}
            <NavLink activeClassName="act" to='/contact/about'>About</NavLink>{' '}
                
            </nav>
            <Switch>
            <Route path='/contact/home' component={Home}/>
            <Route path='/contact/about' component={About}/>
            <Redirect to="/contact/home"/>         
            </Switch>
        </div>

        </div>
    )
}
