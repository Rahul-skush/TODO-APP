import React from 'react'
import Home from './Home'
import About from './About'
import Contact from './Contact'
import {Switch, Route, Redirect} from 'react-router'
import {NavLink} from 'react-router-dom'
import './nav.css'

export default function App() {
    return (
        <div>
            <nav>
            <NavLink activeClassName="act" to='/home'>Home</NavLink>{' '}
            <NavLink activeClassName="act" to='/about'>About</NavLink>{' '}
            <NavLink activeClassName="act" to='/contact'>Contact</NavLink>
                
            </nav>
            <Switch>
            <Route path='/home' component={Home}/>
            <Route path='/about' component={About}/>
            <Route path='/contact' component={Contact}/>   
            <Redirect to="/home"/>         
            </Switch>
        </div>
    )
}
