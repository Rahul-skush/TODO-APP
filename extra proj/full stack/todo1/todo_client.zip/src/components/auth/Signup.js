import React, { useState } from 'react'

export default function Signup(props) {
    const [email, setemail] = useState("")
    const [password, setpassword] = useState("")
    const [name, setname] = useState("")
    const onClkHand = () => {
        props.signUp(email, password, name)
    } 
    return (
        <div>
            <input value={name} onChange={(e)=>{setname(e.target.value)}} type="text" />
            <input value={email} onChange={(e)=>{setemail(e.target.value)}} type="email" />
            <input value={password} onChange={(e)=>{setpassword(e.target.value)}} type="password" />
            <button onClick={onClkHand}>Signup</button>
        </div>
    )
}
