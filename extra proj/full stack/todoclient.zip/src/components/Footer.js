import React, { Component } from 'react'

export default class Footer extends Component {
    render() {
        return (
            <div style={{backgroundColor:'pink'}}>
                <p style={{textAlign:"center", margin:0, backgroundColor:"#440000", color: "white", padding:"10px"}} >Copyright &copy; Todo</p>
            </div>
        )
    }
}
