import React, { Component } from 'react'
import Login from '../../components/auth/Login'
import {connect} from 'react-redux'
import {signup, login, logout} from '../../store/actions'
import withErrorHand from '../../hoc/withErrorHand'
import axios from '../../axios'
import Signup from '../../components/auth/Signup';
class Auth extends Component {    
    render() {
        let out =  (
        <div>
            {/* <Login login={this.props.login} /> */}
            <Signup signup={this.props.signup} />
        </div>
        )
        if(this.props.isAuth){
            out = <button onClick={()=>{this.props.logout()}}>Logout</button>
        }
        return out;
    }
}

const mapStateToProps = state => {
    return {
        token: state.auth.token,
        userid: state.auth.userid,
    }
}
const mapDispatchToProps = dispatch => {
    return {
        signup: (email, password, name) => dispatch(signup(email, password, name)),
        login: (email, password) => dispatch(login(email, password)),
        logout: () => dispatch(logout()),
    }
}

export default connect(mapStateToProps, mapDispatchToProps)( withErrorHand(Auth, axios))
