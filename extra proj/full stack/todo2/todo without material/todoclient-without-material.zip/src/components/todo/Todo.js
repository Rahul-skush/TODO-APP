import React, { useState } from 'react'

export default function Todo(props) {

    const [title, settitle] = useState(props.t1.title)
    
    const onCompHand = () => {
        props.completeTodo(props.t1);
    }
    const onDelHand = () => {
        props.deleteTodo(props.t1);
    }
    const onUpHand = () => {
        props.t1.title = title
        props.updateTodo(props.t1);
    }
    return (
        <div>
            <p>{props.t1.title}
            <input value={title} onChange={(e)=>{settitle(e.target.value)}} />
            <button onClick={onUpHand}>Update</button>
            <button onClick={onCompHand}>Complete</button>
            <button onClick={onDelHand}>Delete</button>
            </p>
        </div>
    )
}
