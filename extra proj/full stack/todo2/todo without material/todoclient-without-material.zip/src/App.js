import React, { Component } from 'react'
import Todo from './containers/todo/Todo'
import Auth from './containers/auth/Auth';
import {connect} from 'react-redux'
import { autoLoginCheck } from './store/actions';
class App extends Component {
  componentDidMount(){
    this.props.autoLoginCheck();
  }
  render() {
    return (
      <div>
        <h1>Todo App </h1>
        
        <Auth isAuth={this.props.isAuth}/>
        {  this.props.isAuth   ? <Todo /> : null }
      </div>
    )
  }
}
const mapStateToProps = state => {
  return {
    isAuth: state.auth.token != null,
  }
}
const mapDispatchToProps = dispatch => {
  return {
    autoLoginCheck: () => {dispatch(autoLoginCheck())},
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(App)
