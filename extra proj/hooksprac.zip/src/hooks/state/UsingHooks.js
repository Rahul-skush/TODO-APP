import React, {useState} from 'react'

export default function UsingHooks() {
    const [name, setname] = useState('bla')
    return (
        <div>
            <input name="name" value={name} onChange={(e)=>{setname(e.target.value)}}  />
        </div>
    )
}
