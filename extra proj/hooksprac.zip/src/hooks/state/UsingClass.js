import React, { Component } from 'react'

export default class index extends Component {
    state = {
        name: '',
    }
    m1 = (e) => {
        this.setState({
            [e.target.name]:e.target.value
        })
    }
    render() {
        console.log(this.state.name)
        return (
            <div>
                <input name="name"  onChange={this.m1} value={this.state.name} />
            </div>
        )
    }
}
