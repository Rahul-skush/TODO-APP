import React from 'react'
import UseingClass from './UsingClass'
import UsingHooks from './UsingHooks'

export default function index() {
    return (
        <div>
            <UseingClass />
            <hr/>
            <UsingHooks />
        </div>
    )
}
