import React, {useEffect} from 'react'

export default function MyComp(props) {
    useEffect(() => {
        console.log("MyComp updated!!!.......");
    })
    return (
        <div>
            {+props.a + +props.b}
        </div>
    )
}
