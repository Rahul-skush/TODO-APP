import React, {useContext} from 'react'
import MyCtx from './MyCtx'
export default function B(props) {
    const context = useContext(MyCtx)
    return (
        <div>
            <h1>{context.count}</h1>
        </div>
    )
}
