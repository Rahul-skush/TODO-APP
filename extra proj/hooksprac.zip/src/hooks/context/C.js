import React, { Component, useContext } from 'react'
import MyCtx from './MyCtx'

class C extends Component {   
    render() {
        return (
            <MyCtx.Consumer>
                {
                    (context) => (
                            <h1>{context.count}</h1>
                    )
                }
            </MyCtx.Consumer>
        )
    }
}
// C.contextType=MyCtx
export default C
