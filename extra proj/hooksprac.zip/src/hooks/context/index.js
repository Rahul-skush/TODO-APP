import React, {useState} from 'react'
import A from './A'
import MyCtx from './MyCtx'

export default function Index() {
    const [a, seta] = useState(0)
    return (
        <MyCtx.Provider value={{count:a}}>
            <A />
            <input value={a} onChange={(e)=>{seta(e.target.value)}} />
        </MyCtx.Provider>
    )
}
