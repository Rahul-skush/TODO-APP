import React, {useEffect} from 'react'
export default function UsingHooks(props) {
    console.log("i am render....2")
    useEffect(() => {
        console.log("For componentDidMount...........2")
        return () => {
            console.log("For componentWillUnmount............2")        
        }    
    }, [])
    useEffect(() => {
        console.log("For componentDidUpdate............2")
    })
    useEffect(() => {
        console.log("dpend on a useEffect*******************************2")
    }, [props.b])
    return (
        <div>
                <h1>hooks</h1>                            
        </div>
    )
}
