import React, {useState} from 'react'
import UsingClass from './UsingClass'
import UsingHooks from './UsingHooks'

export default function Index() {
    const [a, seta] = useState(0)
    return (
        <div>
            <h1>{a}</h1>
            { a<4? <UsingClass /> : null }
            <hr/>
            { a<4? <UsingHooks a={a} b="bla" /> : null }            
            <button onClick={()=>{seta(a+1)}}>Clk Me</button>
        </div>
    )
}
