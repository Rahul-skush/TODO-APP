import React, {useRef} from 'react'
import MyComp from './MyComp'

export default function Index() {
    // const myref = React.createRef(null);
    const myref = useRef(null);
    const m1 = () => {
        myref.current.focus();
    }
    return (
        <div>
            {/* <input ref={myref}/> */}
            <MyComp ref={myref}/>
            <button onClick={m1}>Clk me</button>
        </div>
    )
}
